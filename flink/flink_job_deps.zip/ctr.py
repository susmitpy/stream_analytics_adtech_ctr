from query_loader import render_sql
from pyflink.table import EnvironmentSettings, TableEnvironment
from pyflink.table import expressions as E
from pyflink.table.window import Tumble

def setup_tables(t_env: TableEnvironment):
    # Impressions table
    tbl_impressions = render_sql('tbl_impressions')
    print(tbl_impressions)
    t_env.execute_sql(tbl_impressions)

    # Clicks table
    tbl_clicks = render_sql('tbl_clicks')
    print(tbl_clicks)
    t_env.execute_sql(tbl_clicks)

    # CTR table
    tbl_ctr = render_sql('tbl_ctr')
    print(tbl_ctr)
    t_env.execute_sql(tbl_ctr)

def compute_ctr(t_env: TableEnvironment):
    t_env.execute_sql("""
    CREATE TEMPORARY VIEW impressions_dedup AS
    SELECT impr_id, user_id, campaign_id, ts
    FROM (
      SELECT *,
             ROW_NUMBER() OVER (PARTITION BY impr_id ORDER BY ts DESC) AS rn
      FROM impressions
    )
    WHERE rn = 1
    """)
    t_env.execute_sql("""
    CREATE TEMPORARY VIEW clicks_dedup AS
    SELECT click_id, impr_id, user_id, ts
    FROM (
      SELECT *,
             ROW_NUMBER() OVER (PARTITION BY click_id ORDER BY ts DESC) AS rn
      FROM clicks
    )
    WHERE rn = 1
    """)

    # Load deduplicated tables
    impressions_dedup = t_env.from_path("impressions_dedup")
    clicks_dedup = t_env.from_path("clicks_dedup")

    i = impressions_dedup.alias("i")
    c = clicks_dedup.alias("c")

    # Interval join to find clicks within 12 seconds of impressions
    joined = (
        i.join(c)
         .where(
             (E.col("i.impr_id") == E.col("c.impr_id")) &
             (E.col("c.ts") >= E.col("i.ts")) &
             (E.col("c.ts") <= E.col("i.ts") + E.lit("INTERVAL '12' SECOND"))
         )
         .select(E.col("i.campaign_id").alias("campaign_id"),
                 E.col("i.ts").alias("imp_ts"),
                 E.col("c.ts").alias("clk_ts"),
                 E.col("c.click_id"))
    )

    # Impressions per campaign
    imp_win = (
        i.window(Tumble.over(E.lit(15).seconds).on(E.col("ts")).alias("w"))
         .group_by(E.col("campaign_id"), E.col("w"))
         .select(
             E.col("campaign_id"),
             E.col("w").start.alias("window_start"),
             E.col("w").end.alias("window_end"),
             E.lit(1).count.alias("impressions")
         )
    )

    clicks_win = (
        joined.window(Tumble.over(E.lit(1).minutes).on(E.col("imp_ts")).alias("w"))
              .group_by(E.col("campaign_id"), E.col("w"))
              .select(
                  E.col("campaign_id"),
                  E.col("w").start.alias("window_start"),
                  E.col("w").end.alias("window_end"),
                  E.col("click_id").count.alias("clicks")
              )
    )

    ctr = (
        imp_win.join(clicks_win)
               .where(
                   (imp_win.get_column("campaign_id") == clicks_win.get_column("campaign_id")) &
                   (imp_win.get_column("window_start") == clicks_win.get_column("window_start")) &
                   (imp_win.get_column("window_end") == clicks_win.get_column("window_end"))
               )
               .select(
                   imp_win.get_column("campaign_id").alias("campaign_id"),
                   imp_win.get_column("window_start"),
                   imp_win.get_column("window_end"),
                   imp_win.get_column("impressions"),
                   clicks_win.get_column("clicks"),
                   (clicks_win.get_column("clicks").cast("DOUBLE") /
                    imp_win.get_column("impressions").nullif(0).cast("DOUBLE")).alias("ctr")
               )
    )

    # Insert into the CTR table
    ctr.execute_insert("ctr_by_campaign").wait()


def main():
    env_settings = EnvironmentSettings.in_streaming_mode()
    t_env = TableEnvironment.create(env_settings)
    setup_tables(t_env=t_env)
    compute_ctr(t_env=t_env)


if __name__ == "__main__":
    main()
