CREATE TABLE IF NOT EXISTS ctr_by_campaign (
      campaign_id STRING,
      window_start TIMESTAMP_LTZ(3),
      window_end   TIMESTAMP_LTZ(3),
      impressions BIGINT,
      clicks      BIGINT,
      ctr         DOUBLE,
      PRIMARY KEY (campaign_id, window_start, window_end) NOT ENFORCED
    ) WITH (
      'connector' = 'mongodb',
      'uri' = 'mongodb://mongodb:27017',
      'database' = 'adtech',
      'collection' = 'ctr_by_campaign',
      'sink.buffer-flush.max-rows' = '100',
      'sink.buffer-flush.interval' = '2 s'
    )