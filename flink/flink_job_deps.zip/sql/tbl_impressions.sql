CREATE TABLE IF NOT EXISTS impressions (
      impr_id STRING,
      user_id STRING,
      campaign_id STRING,
      ts TIMESTAMP_LTZ(3),
      WATERMARK FOR ts AS ts - INTERVAL '5' SECOND
    ) WITH (
      'connector' = 'kafka',
      'topic' = 'impressions',
      'properties.bootstrap.servers' = 'kafka:29092',
      'properties.group.id' = 'pyflink-ctr',
      'scan.startup.mode' = 'earliest-offset',
      'value.format' = 'json',
      'json.ignore-parse-errors' = 'true',
      'scan.watermark.idle-timeout' = '5 s'
    )